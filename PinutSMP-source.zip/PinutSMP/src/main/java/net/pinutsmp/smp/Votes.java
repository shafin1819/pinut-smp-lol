package net.pinutsmp.smp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Pattern;

/** A vote arrived: rewards, chat broadcast, Discord message. Offline voters get rewards on next join. */
final class Votes implements Listener {
    /** Only these characters may reach a console command (blocks command injection through a fake name). */
    private static final Pattern VALID_NAME = Pattern.compile("[A-Za-z0-9_.]{1,24}");
    private static final int MAX_PENDING = 10;

    private final PinutSMP plugin;
    private final DiscordSender sender;
    private final File dataFile;
    private final YamlConfiguration data;

    Votes(PinutSMP plugin, DiscordSender sender) {
        this.plugin = plugin;
        this.sender = sender;
        this.dataFile = new File(plugin.getDataFolder(), "votes-data.yml");
        this.data = YamlConfiguration.loadConfiguration(dataFile);
    }

    private FileConfiguration c() {
        return plugin.getConfig();
    }

    /** Safe to call from any thread (Votifier threads use this). */
    void submit(String user, String service) {
        Bukkit.getScheduler().runTask(plugin, () -> handle(user, service));
    }

    /** Main thread only. */
    void handle(String user, String service) {
        if (user == null || !VALID_NAME.matcher(user).matches()) {
            plugin.getLogger().warning("Ignored a vote with an invalid username: " + user);
            return;
        }
        String key = key(user);
        int total = data.getInt("votes." + key, 0) + 1;
        data.set("votes." + key, total);

        Player p = Bukkit.getPlayerExact(user);
        if (p != null) {
            giveRewards(p.getName(), service);
            for (String line : c().getStringList("vote.rewards.message")) {
                p.sendMessage(Text.color(ph(line, p.getName(), service, total)));
            }
        } else if (c().getBoolean("vote.rewards.give-offline", true)) {
            data.set("pending." + key, Math.min(MAX_PENDING, data.getInt("pending." + key, 0) + 1));
        }
        save();

        broadcast(user, service, total);
        discord(user, service, total);
    }

    // ------------------------------------------------------------------ rewards

    private void giveRewards(String name, String service) {
        for (String cmd : c().getStringList("vote.rewards.commands")) run(cmd, name, service);

        for (Map<?, ?> entry : c().getMapList("vote.rewards.random")) {
            Object ch = entry.get("chance");
            double chance = ch instanceof Number n ? n.doubleValue() : 0;
            if (ThreadLocalRandom.current().nextDouble(100.0) >= chance) continue;
            if (entry.get("commands") instanceof List<?> cmds) {
                for (Object o : cmds) run(String.valueOf(o), name, service);
            }
        }
    }

    private void run(String cmd, String name, String service) {
        String line = cmd.replace("%player%", name).replace("{player}", name)
                .replace("%service%", service).replace("{service}", service).trim();
        if (line.startsWith("/")) line = line.substring(1);
        if (line.isEmpty()) return;
        try {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), line);
        } catch (Exception ex) {
            plugin.getLogger().warning("Reward command failed (" + line + "): " + ex.getMessage());
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        String key = key(p.getName());
        if (data.getInt("pending." + key, 0) <= 0) return;

        long delay = c().getLong("vote.rewards.offline-delay-ticks", 100L);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline()) return;
            int n = Math.min(MAX_PENDING, data.getInt("pending." + key, 0));
            if (n <= 0) return;
            data.set("pending." + key, null);
            save();
            int total = data.getInt("votes." + key, n);
            for (int i = 0; i < n; i++) giveRewards(p.getName(), "offline");
            for (String line : c().getStringList("vote.rewards.message")) {
                p.sendMessage(Text.color(ph(line, p.getName(), "offline", total)));
            }
        }, delay);
    }

    // ------------------------------------------------------------------ messages

    private void broadcast(String player, String service, int total) {
        if (!c().getBoolean("vote.broadcast.enabled", true)) return;
        for (String line : c().getStringList("vote.broadcast.lines")) {
            Bukkit.broadcast(Text.color(ph(line, player, service, total)));
        }
        String click = c().getString("vote.broadcast.click-line", "");
        if (click != null && !click.isBlank()) {
            Bukkit.broadcast(Text.color(ph(click, player, service, total))
                    .clickEvent(ClickEvent.openUrl(c().getString("vote.link", "")))
                    .hoverEvent(HoverEvent.showText(Text.color("&7Open the vote page"))));
        }
    }

    private void discord(String player, String service, int total) {
        String url = c().getString("webhooks.votes", "");
        if (!DiscordSender.valid(url)) return;

        String safe = player.replace("\\", "\\\\").replace("_", "\\_").replace("*", "\\*")
                .replace("~", "\\~").replace("`", "\\`").replace("|", "\\|");
        String head = c().getString("avatar-url", "https://mc-heads.net/avatar/%name%/128")
                .replace("%uuid%", "")
                .replace("%name%", URLEncoder.encode(player, StandardCharsets.UTF_8));
        int color;
        try {
            color = Integer.parseInt(c().getString("vote.discord.color", "FEE75C").replace("#", ""), 16);
        } catch (NumberFormatException ex) {
            color = 0xFEE75C;
        }
        Embed em = new Embed();
        em.title = ph(c().getString("vote.discord.title", "New vote!"), safe, service, total);
        em.description = ph(c().getString("vote.discord.description", "**{player}** voted!"), safe, service, total);
        em.thumbnail = head;
        em.color = color;
        em.footerText = ph(c().getString("vote.discord.footer", "{server}"), safe, service, total);
        em.footerIcon = c().getString("server-icon-url", "");

        sender.send(url, Embed.payload(c().getString("vote.discord.username", "PinutSMP Votes"),
                c().getString("server-icon-url", ""), null, List.of(em)));
    }

    // ------------------------------------------------------------------ helpers

    private String ph(String s, String player, String service, int total) {
        return s.replace("%player%", player).replace("{player}", player)
                .replace("%service%", service).replace("{service}", service)
                .replace("{votes}", String.valueOf(total))
                .replace("{server}", c().getString("server-name", "PinutSMP"))
                .replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()))
                .replace("{max}", String.valueOf(Bukkit.getMaxPlayers()))
                .replace("{link}", c().getString("vote.link", ""));
    }

    /** Data-file key: lower-case, no dots (dots would create nested YAML sections). */
    private static String key(String name) {
        return name.toLowerCase(Locale.ROOT).replace('.', '~');
    }

    private void save() {
        try {
            data.save(dataFile);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save votes-data.yml: " + ex.getMessage());
        }
    }
}
