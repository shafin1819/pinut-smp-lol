package net.pinutsmp.smp;

import java.time.Instant;
import java.util.List;

/** One Discord embed + helpers to build the final webhook JSON. */
final class Embed {
    String title;
    String description;
    String authorName;
    String authorIcon;
    String thumbnail;
    String footerText;
    String footerIcon;
    int color = 0x2B2D31;
    boolean timestamp = true;

    static String q(String s) {
        if (s == null) s = "";
        StringBuilder sb = new StringBuilder(s.length() + 8).append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
                }
            }
        }
        return sb.append('"').toString();
    }

    static String cut(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max - 1) + "\u2026";
    }

    private static boolean has(String s) {
        return s != null && !s.isBlank();
    }

    String toJson() {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"color\":").append(color);
        if (has(title)) sb.append(",\"title\":").append(q(cut(title, 250)));
        if (has(description)) sb.append(",\"description\":").append(q(cut(description, 4000)));
        if (has(authorName)) {
            sb.append(",\"author\":{\"name\":").append(q(cut(authorName, 250)));
            if (has(authorIcon)) sb.append(",\"icon_url\":").append(q(authorIcon));
            sb.append('}');
        }
        if (has(thumbnail)) sb.append(",\"thumbnail\":{\"url\":").append(q(thumbnail)).append('}');
        if (has(footerText)) {
            sb.append(",\"footer\":{\"text\":").append(q(cut(footerText, 2000)));
            if (has(footerIcon)) sb.append(",\"icon_url\":").append(q(footerIcon));
            sb.append('}');
        }
        if (timestamp) sb.append(",\"timestamp\":").append(q(Instant.now().toString()));
        return sb.append('}').toString();
    }

    /** Full webhook body. Mentions (@everyone etc.) are always disabled. */
    static String payload(String username, String avatarUrl, String content, List<Embed> embeds) {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"username\":").append(q(cut(username == null || username.isBlank() ? "PinutSMP" : username, 80)));
        if (has(avatarUrl)) sb.append(",\"avatar_url\":").append(q(avatarUrl));
        if (has(content)) sb.append(",\"content\":").append(q(cut(content, 1900)));
        sb.append(",\"allowed_mentions\":{\"parse\":[]}");
        if (embeds != null && !embeds.isEmpty()) {
            sb.append(",\"embeds\":[");
            for (int i = 0; i < embeds.size(); i++) {
                if (i > 0) sb.append(',');
                sb.append(embeds.get(i).toJson());
            }
            sb.append(']');
        }
        return sb.append('}').toString();
    }
}
