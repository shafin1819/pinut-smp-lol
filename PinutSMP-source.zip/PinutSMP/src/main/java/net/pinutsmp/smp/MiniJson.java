package net.pinutsmp.smp;

import java.util.HashMap;
import java.util.Map;

/** Tiny parser for FLAT json objects ({"a":"b","n":123}). Enough for Votifier v2 messages. */
final class MiniJson {
    private MiniJson() {}

    static Map<String, String> parseFlat(String s) {
        Map<String, String> out = new HashMap<>();
        int[] i = {0};
        skipWs(s, i);
        expect(s, i, '{');
        skipWs(s, i);
        if (peek(s, i) == '}') return out;
        while (true) {
            skipWs(s, i);
            String key = readString(s, i);
            skipWs(s, i);
            expect(s, i, ':');
            skipWs(s, i);
            String value;
            char c = peek(s, i);
            if (c == '"') {
                value = readString(s, i);
            } else {
                int start = i[0];
                while (i[0] < s.length() && ",}".indexOf(s.charAt(i[0])) < 0) i[0]++;
                value = s.substring(start, i[0]).trim();
                if (value.equals("null")) value = "";
            }
            out.put(key, value);
            skipWs(s, i);
            char n = peek(s, i);
            i[0]++;
            if (n == '}') return out;
            if (n != ',') throw new IllegalArgumentException("bad json");
        }
    }

    private static char peek(String s, int[] i) {
        if (i[0] >= s.length()) throw new IllegalArgumentException("unexpected end");
        return s.charAt(i[0]);
    }

    private static void expect(String s, int[] i, char c) {
        if (peek(s, i) != c) throw new IllegalArgumentException("expected " + c);
        i[0]++;
    }

    private static void skipWs(String s, int[] i) {
        while (i[0] < s.length() && Character.isWhitespace(s.charAt(i[0]))) i[0]++;
    }

    private static String readString(String s, int[] i) {
        expect(s, i, '"');
        StringBuilder sb = new StringBuilder();
        while (true) {
            char c = peek(s, i);
            i[0]++;
            if (c == '"') return sb.toString();
            if (c != '\\') {
                sb.append(c);
                continue;
            }
            char e = peek(s, i);
            i[0]++;
            switch (e) {
                case 'n' -> sb.append('\n');
                case 'r' -> sb.append('\r');
                case 't' -> sb.append('\t');
                case 'b' -> sb.append('\b');
                case 'f' -> sb.append('\f');
                case 'u' -> {
                    if (i[0] + 4 > s.length()) throw new IllegalArgumentException("bad escape");
                    sb.append((char) Integer.parseInt(s.substring(i[0], i[0] + 4), 16));
                    i[0] += 4;
                }
                default -> sb.append(e); // \" \\ \/
            }
        }
    }
}
