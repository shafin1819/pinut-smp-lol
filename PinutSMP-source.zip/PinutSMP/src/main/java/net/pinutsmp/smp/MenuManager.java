package net.pinutsmp.smp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/** Chest menus (/vote, /discord). Everything comes from config.yml -> menus.<id>. */
final class MenuManager implements Listener {
    private final PinutSMP plugin;

    MenuManager(PinutSMP plugin) {
        this.plugin = plugin;
    }

    /** Marker so we only touch our own inventories. */
    static final class Holder implements InventoryHolder {
        final String id;
        private Inventory inventory;

        Holder(String id) {
            this.id = id;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private FileConfiguration c() {
        return plugin.getConfig();
    }

    /** /vote or /discord. */
    void command(CommandSender sender, String id) {
        ConfigurationSection menu = c().getConfigurationSection("menus." + id);
        if (menu == null) {
            sender.sendMessage(Text.color("&cThis menu is not configured."));
            return;
        }
        if (!(sender instanceof Player p)) {
            ConfigurationSection link = firstLink(menu);
            if (link != null) sender.sendMessage(Component.text(link.getString("link", "")));
            return;
        }
        if (menu.getBoolean("enabled", true)) {
            open(p, id, menu);
        } else {
            ConfigurationSection link = firstLink(menu);
            if (link != null) sendLink(p, link);
        }
    }

    private ConfigurationSection firstLink(ConfigurationSection menu) {
        ConfigurationSection items = menu.getConfigurationSection("items");
        if (items == null) return null;
        for (String key : items.getKeys(false)) {
            ConfigurationSection s = items.getConfigurationSection(key);
            if (s != null && "link".equalsIgnoreCase(s.getString("action", "none"))) return s;
        }
        return null;
    }

    private void open(Player p, String id, ConfigurationSection menu) {
        int rows = Math.max(1, Math.min(6, menu.getInt("rows", 3)));
        Holder holder = new Holder(id);
        Inventory inv = Bukkit.createInventory(holder, rows * 9, Text.color(menu.getString("title", "&8Menu")));
        holder.inventory = inv;

        Material filler = Material.matchMaterial(menu.getString("filler", "AIR"));
        if (filler != null && filler != Material.AIR) {
            ItemStack f = make(filler, " ", List.of());
            for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, f);
        }

        ConfigurationSection items = menu.getConfigurationSection("items");
        if (items != null) {
            for (String key : items.getKeys(false)) {
                ConfigurationSection s = items.getConfigurationSection(key);
                if (s == null) continue;
                int slot = s.getInt("slot", 13);
                if (slot < 0 || slot >= inv.getSize()) continue;
                Material m = Material.matchMaterial(s.getString("material", "CANDLE"));
                if (m == null) m = Material.CANDLE;
                inv.setItem(slot, make(m, s.getString("name", "&aClick"), s.getStringList("lore")));
            }
        }
        p.openInventory(inv);
    }

    private ItemStack make(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.displayName(Text.item(name));
            if (!lore.isEmpty()) meta.lore(Text.items(lore));
            it.setItemMeta(meta);
        }
        return it;
    }

    /** Chat lines + clickable link + sound. */
    void sendLink(Player p, ConfigurationSection item) {
        String link = item.getString("link", "");
        for (String line : item.getStringList("message")) {
            p.sendMessage(Text.color(line.replace("%player%", p.getName()).replace("%link%", link)));
        }
        Component click = Text.color(item.getString("click-text", "&a&l[CLICK HERE]").replace("%link%", link))
                .clickEvent(ClickEvent.openUrl(link))
                .hoverEvent(HoverEvent.showText(Text.color(item.getString("hover-text", "&7Open the link"))));
        p.sendMessage(click);

        ConfigurationSection snd = c().getConfigurationSection("sounds.click");
        if (snd != null && snd.getBoolean("enabled", true)) {
            try {
                p.playSound(p.getLocation(), snd.getString("sound", "minecraft:block.note_block.pling"),
                        (float) snd.getDouble("volume", 0.5), (float) snd.getDouble("pitch", 1.0));
            } catch (Throwable ignored) {
                // sound problems must never break the menu
            }
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;

        ConfigurationSection items = c().getConfigurationSection("menus." + holder.id + ".items");
        if (items == null) return;
        int slot = e.getRawSlot();
        for (String key : items.getKeys(false)) {
            ConfigurationSection s = items.getConfigurationSection(key);
            if (s == null || s.getInt("slot", -1) != slot) continue;
            if ("link".equalsIgnoreCase(s.getString("action", "none"))) {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    p.closeInventory();
                    sendLink(p, s);
                });
            }
            return;
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
