package net.pinutsmp.smp;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Sends webhooks one by one on its own thread (never lags the server) and obeys Discord rate limits. */
final class DiscordSender {
    private static final Pattern URL =
            Pattern.compile("https://(?:(?:canary|ptb)\\.)?discord(?:app)?\\.com/api/webhooks/\\d+/[\\w-]+");
    private static final Pattern RETRY = Pattern.compile("\"retry_after\"\\s*:\\s*([0-9.]+)");

    private final Logger log;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "PinutSMP-Discord");
        t.setDaemon(true);
        return t;
    });
    private final AtomicInteger queued = new AtomicInteger();

    DiscordSender(Logger log) {
        this.log = log;
    }

    static boolean valid(String url) {
        return url != null && URL.matcher(url.trim()).matches();
    }

    void send(String url, String json) {
        if (!valid(url)) return;
        if (queued.get() > 150) {
            log.warning("Discord queue is full - dropping a message.");
            return;
        }
        queued.incrementAndGet();
        try {
            exec.execute(() -> {
                try {
                    post(url.trim(), json);
                } finally {
                    queued.decrementAndGet();
                }
            });
        } catch (RuntimeException ex) {
            queued.decrementAndGet(); // already shut down
        }
    }

    private void post(String url, String json) {
        for (int attempt = 0; attempt < 4; attempt++) {
            try {
                HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                        .timeout(Duration.ofSeconds(15))
                        .header("Content-Type", "application/json; charset=utf-8")
                        .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                        .build();
                HttpResponse<String> r = http.send(req, HttpResponse.BodyHandlers.ofString());
                int sc = r.statusCode();
                if (sc == 429) {
                    Thread.sleep(Math.min(10_000L, retryMillis(r)));
                    continue;
                }
                if (sc >= 300) log.warning("Discord webhook answered HTTP " + sc + ": " + r.body());
                return;
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                return;
            } catch (Exception ex) {
                log.warning("Discord webhook failed: " + ex.getMessage());
                return;
            }
        }
    }

    private static long retryMillis(HttpResponse<String> r) {
        try {
            String h = r.headers().firstValue("Retry-After").orElse(null);
            if (h != null) return (long) (Double.parseDouble(h) * 1000) + 100;
            Matcher m = RETRY.matcher(r.body());
            if (m.find()) return (long) (Double.parseDouble(m.group(1)) * 1000) + 100;
        } catch (Exception ignored) {
        }
        return 2000;
    }

    /** Lets queued messages (like "Server Offline") go out before the server closes. */
    void shutdown() {
        exec.shutdown();
        try {
            exec.awaitTermination(4, TimeUnit.SECONDS);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
    }
}
