package net.pinutsmp.smp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

import java.util.ArrayList;
import java.util.List;

/** Turns "&a&lText" (and &#RRGGBB) into Adventure components. */
final class Text {
    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private Text() {}

    static Component color(String s) {
        return LEGACY.deserialize(s == null ? "" : s);
    }

    /** Same, but without Minecraft's default italic (item names / lore). */
    static Component item(String s) {
        return color(s).decoration(TextDecoration.ITALIC, false);
    }

    static List<Component> items(List<String> lines) {
        List<Component> out = new ArrayList<>();
        for (String l : lines) out.add(item(l));
        return out;
    }
}
