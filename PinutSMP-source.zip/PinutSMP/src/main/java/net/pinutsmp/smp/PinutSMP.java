package net.pinutsmp.smp;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.List;
import java.util.Locale;

/**
 * PinutSMP - everything in ONE plugin:
 * Minecraft -> Discord bridge (join/leave/chat), /vote + /discord menus,
 * built-in Votifier receiver, vote rewards and the Discord vote message.
 */
public final class PinutSMP extends JavaPlugin implements CommandExecutor {
    private DiscordSender sender;
    private Bridge bridge;
    private MenuManager menus;
    private Votes votes;
    private VotifierServer votifier;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        sender = new DiscordSender(getLogger());
        bridge = new Bridge(this, sender);
        menus = new MenuManager(this);
        votes = new Votes(this, sender);

        Bukkit.getPluginManager().registerEvents(bridge, this);
        Bukkit.getPluginManager().registerEvents(menus, this);
        Bukkit.getPluginManager().registerEvents(votes, this);

        for (String name : List.of("vote", "discord", "pinutsmp")) {
            if (getCommand(name) != null) getCommand(name).setExecutor(this);
        }

        startVotifier();
        // post "Server Online" once the server has finished starting
        Bukkit.getScheduler().runTask(this, () -> bridge.serverState(true));
    }

    @Override
    public void onDisable() {
        if (bridge != null) bridge.serverState(false);
        if (votifier != null) votifier.stop();
        if (sender != null) sender.shutdown();
    }

    private void startVotifier() {
        if (!getConfig().getBoolean("vote.votifier.enabled", true)) return;
        String host = getConfig().getString("vote.votifier.host", "0.0.0.0");
        int port = getConfig().getInt("vote.votifier.port", 8192);
        votifier = new VotifierServer(getLogger(), new File(getDataFolder(), "votifier"), host, port,
                (service, user, address, timestamp) -> votes.submit(user, service));
        if (votifier.start()) {
            getLogger().info("Votifier is listening on " + host + ":" + port);
            getLogger().info("Votifier public key (v1): " + votifier.publicKey());
            getLogger().info("Votifier token (v2): " + votifier.token());
        } else {
            votifier = null;
        }
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        if (name.equals("vote") || name.equals("discord")) {
            menus.command(s, name);
            return true;
        }

        // /pinutsmp ...
        if (!s.hasPermission("pinutsmp.admin")) {
            s.sendMessage(Text.color("&cYou do not have permission."));
            return true;
        }
        String sub = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "";
        switch (sub) {
            case "reload" -> {
                reloadConfig();
                s.sendMessage(Text.color("&aPinutSMP config reloaded. &7(A changed Votifier port needs a restart.)"));
            }
            case "test" -> {
                sendTests();
                s.sendMessage(Text.color("&aTest messages sent to the status, chat and votes webhooks. Check Discord."));
            }
            case "votetest" -> {
                if (args.length < 2) {
                    s.sendMessage(Text.color("&7Usage: &e/pinutsmp votetest <player>"));
                } else {
                    s.sendMessage(Text.color("&eSimulating a vote for &6" + args[1] + "&e (rewards and webhook are REAL)."));
                    votes.handle(args[1], "TEST");
                }
            }
            case "votifier" -> {
                if (votifier == null) {
                    s.sendMessage(Text.color("&cVotifier is not running. Check the console for the reason."));
                } else {
                    s.sendMessage(Text.color("&6Votifier port: &f" + votifier.port()));
                    s.sendMessage(Text.color("&6Public key (v1): &f" + votifier.publicKey()));
                    s.sendMessage(Text.color("&6Token (v2): &f" + votifier.token()));
                }
            }
            default -> s.sendMessage(Text.color(
                    "&7Usage: &e/pinutsmp reload &7| &etest &7| &evotetest <player> &7| &evotifier"));
        }
        return true;
    }

    private void sendTests() {
        String server = getConfig().getString("server-name", "PinutSMP");
        String icon = getConfig().getString("server-icon-url", "");
        Embed e = new Embed();
        e.title = "Test message";
        e.description = "If you can read this, this webhook works.";
        e.color = 0x5865F2;
        e.footerText = server;
        String json = Embed.payload(server, icon, null, List.of(e));
        sender.send(getConfig().getString("webhooks.status", ""), json);
        sender.send(getConfig().getString("webhooks.votes", ""), json);
        sender.send(getConfig().getString("webhooks.chat", ""),
                Embed.payload(server, icon, "Test message - the chat webhook works.", null));
    }
}
