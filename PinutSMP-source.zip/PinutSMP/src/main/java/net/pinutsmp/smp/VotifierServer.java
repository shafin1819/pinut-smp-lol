package net.pinutsmp.smp;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Logger;

/**
 * Built-in Votifier receiver (protocol v1 = RSA public key, protocol v2 = token).
 * No NuVotifier needed. Keys and token are created automatically in the "votifier" folder.
 */
final class VotifierServer {
    interface Handler {
        void onVote(String service, String username, String address, String timestamp);
    }

    private static final int V2_MAGIC = 0x733A;
    private static final String ALNUM = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

    private final Logger log;
    private final File dir;
    private final String host;
    private final int port;
    private final Handler handler;
    private final SecureRandom random = new SecureRandom();

    private PrivateKey privateKey;
    private String publicKeyText;
    private String token;
    private volatile ServerSocket server;
    private ExecutorService pool;

    VotifierServer(Logger log, File dir, String host, int port, Handler handler) {
        this.log = log;
        this.dir = dir;
        this.host = host;
        this.port = port;
        this.handler = handler;
    }

    String publicKey() {
        return publicKeyText;
    }

    String token() {
        return token;
    }

    int port() {
        return server != null ? server.getLocalPort() : port;
    }

    boolean start() {
        try {
            loadOrCreateKeys();
            loadOrCreateToken();
        } catch (Exception ex) {
            log.warning("Votifier: could not prepare keys: " + ex);
            return false;
        }
        try {
            ServerSocket ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(InetAddress.getByName(host), port));
            server = ss;
        } catch (IOException ex) {
            log.warning("Votifier: cannot open port " + port + " (" + ex.getMessage() + "). "
                    + "Your host must give you an extra port for this. Votes will NOT be received.");
            return false;
        }
        pool = Executors.newCachedThreadPool(r -> {
            Thread t = new Thread(r, "PinutSMP-Votifier");
            t.setDaemon(true);
            return t;
        });
        Thread acceptor = new Thread(this::acceptLoop, "PinutSMP-Votifier-Accept");
        acceptor.setDaemon(true);
        acceptor.start();
        return true;
    }

    void stop() {
        ServerSocket ss = server;
        server = null;
        if (ss != null) {
            try {
                ss.close();
            } catch (IOException ignored) {
            }
        }
        if (pool != null) pool.shutdownNow();
    }

    // ------------------------------------------------------------------ keys

    private void loadOrCreateKeys() throws Exception {
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("cannot create " + dir);
        File pub = new File(dir, "public.key");
        File priv = new File(dir, "private.key");
        KeyFactory kf = KeyFactory.getInstance("RSA");
        if (pub.isFile() && priv.isFile()) {
            publicKeyText = Files.readString(pub.toPath(), StandardCharsets.UTF_8).trim();
            byte[] p8 = Base64.getDecoder().decode(Files.readString(priv.toPath(), StandardCharsets.UTF_8).trim());
            privateKey = kf.generatePrivate(new PKCS8EncodedKeySpec(p8));
            kf.generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyText))); // validate
            return;
        }
        KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
        gen.initialize(2048, random);
        KeyPair kp = gen.generateKeyPair();
        privateKey = kp.getPrivate();
        publicKeyText = Base64.getEncoder().encodeToString(kp.getPublic().getEncoded());
        Files.writeString(pub.toPath(), publicKeyText, StandardCharsets.UTF_8);
        Files.writeString(priv.toPath(), Base64.getEncoder().encodeToString(privateKey.getEncoded()), StandardCharsets.UTF_8);
        log.info("Votifier: created a new RSA key pair.");
    }

    private void loadOrCreateToken() throws IOException {
        File f = new File(dir, "token.txt");
        if (f.isFile()) {
            token = Files.readString(f.toPath(), StandardCharsets.UTF_8).trim();
            if (!token.isEmpty()) return;
        }
        token = randomText(24);
        Files.writeString(f.toPath(), token, StandardCharsets.UTF_8);
        log.info("Votifier: created a new token.");
    }

    private String randomText(int n) {
        StringBuilder sb = new StringBuilder(n);
        for (int i = 0; i < n; i++) sb.append(ALNUM.charAt(random.nextInt(ALNUM.length())));
        return sb.toString();
    }

    // ------------------------------------------------------------------ network

    private void acceptLoop() {
        while (true) {
            ServerSocket ss = server;
            if (ss == null || ss.isClosed()) return;
            try {
                Socket s = ss.accept();
                pool.execute(() -> handle(s));
            } catch (IOException ex) {
                if (server == null) return;
                log.warning("Votifier accept error: " + ex.getMessage());
            } catch (RuntimeException ex) {
                return; // pool shut down
            }
        }
    }

    private void handle(Socket s) {
        try (Socket sock = s) {
            sock.setSoTimeout(5000);
            String challenge = randomText(16);
            OutputStream out = sock.getOutputStream();
            out.write(("VOTIFIER 2 " + challenge + "\n").getBytes(StandardCharsets.US_ASCII));
            out.flush();

            DataInputStream in = new DataInputStream(new BufferedInputStream(sock.getInputStream()));
            int first = in.readUnsignedShort();
            if (first == V2_MAGIC) {
                int len = in.readUnsignedShort();
                if (len <= 0 || len > 8192) throw new IOException("bad v2 length");
                byte[] body = new byte[len];
                in.readFully(body);
                try {
                    handleV2(new String(body, StandardCharsets.UTF_8), challenge);
                    reply(out, "{\"status\":\"ok\"}");
                } catch (Exception ex) {
                    log.warning("Votifier v2 vote rejected: " + ex.getMessage());
                    reply(out, "{\"status\":\"error\",\"cause\":\"VotifierProtocol2Exception\",\"error\":\"rejected\"}");
                }
            } else {
                byte[] block = new byte[256];
                block[0] = (byte) (first >> 8);
                block[1] = (byte) first;
                in.readFully(block, 2, 254);
                handleV1(block);
            }
        } catch (Exception ex) {
            log.fine("Votifier connection error: " + ex);
        }
    }

    private static void reply(OutputStream out, String json) throws IOException {
        out.write((json + "\n").getBytes(StandardCharsets.UTF_8));
        out.flush();
    }

    private void handleV1(byte[] block) throws Exception {
        Cipher c = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        c.init(Cipher.DECRYPT_MODE, privateKey);
        String text = new String(c.doFinal(block), StandardCharsets.UTF_8);
        String[] p = text.split("\n");
        if (p.length < 5 || !p[0].equals("VOTE")) throw new IOException("not a vote");
        handler.onVote(p[1], p[2], p[3], p[4]);
    }

    private void handleV2(String message, String challenge) throws Exception {
        Map<String, String> outer = MiniJson.parseFlat(message);
        String payload = outer.get("payload");
        String signature = outer.get("signature");
        if (payload == null || signature == null) throw new IOException("missing payload/signature");

        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(token.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        byte[] expected = mac.doFinal(payload.getBytes(StandardCharsets.UTF_8));
        byte[] given = Base64.getDecoder().decode(signature);
        if (!MessageDigest.isEqual(expected, given)) throw new IOException("bad signature (wrong token?)");

        Map<String, String> vote = MiniJson.parseFlat(payload);
        if (!challenge.equals(vote.get("challenge"))) throw new IOException("bad challenge");
        String user = vote.get("username");
        String service = vote.get("serviceName");
        if (user == null || service == null) throw new IOException("incomplete vote");
        handler.onVote(service, user, vote.getOrDefault("address", ""), vote.getOrDefault("timestamp", ""));
    }
}
