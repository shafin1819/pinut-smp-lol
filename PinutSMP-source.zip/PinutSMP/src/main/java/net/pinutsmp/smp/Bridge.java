package net.pinutsmp.smp;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerAdvancementDoneEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Minecraft -> Discord: join / leave / first join / deaths / advancements / live chat. */
final class Bridge implements Listener {
    private final PinutSMP plugin;
    private final DiscordSender sender;
    private final Map<UUID, Long> joined = new ConcurrentHashMap<>();

    Bridge(PinutSMP plugin, DiscordSender sender) {
        this.plugin = plugin;
        this.sender = sender;
    }

    private FileConfiguration c() {
        return plugin.getConfig();
    }

    // ------------------------------------------------------------------ helpers

    private String text(String key) {
        return c().getString("messages." + key, "");
    }

    private String server() {
        return c().getString("server-name", "PinutSMP");
    }

    private String icon() {
        return c().getString("server-icon-url", "");
    }

    private String head(Player p) {
        return c().getString("avatar-url", "https://mc-heads.net/avatar/%name%/128")
                .replace("%uuid%", p.getUniqueId().toString())
                .replace("%name%", URLEncoder.encode(p.getName(), StandardCharsets.UTF_8));
    }

    private String fmt(String s, String player, String message, String time, int online) {
        return s.replace("{player}", player)
                .replace("{message}", message)
                .replace("{time}", time)
                .replace("{server}", server())
                .replace("{online}", String.valueOf(online))
                .replace("{max}", String.valueOf(Bukkit.getMaxPlayers()));
    }

    private static int hex(Object o, int fallback) {
        try {
            return Integer.parseInt(String.valueOf(o).replace("#", "").trim(), 16);
        } catch (NumberFormatException ex) {
            return fallback;
        }
    }

    private int col(String key, int fallback) {
        return hex(c().getString("colors." + key, ""), fallback);
    }

    private static String plain(Component comp) {
        return comp == null ? "" : PlainTextComponentSerializer.plainText().serialize(comp);
    }

    private static String duration(long ms) {
        long s = Math.max(0, ms / 1000);
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        if (h > 0) return h + "h " + m + "m";
        if (m > 0) return m + "m " + sec + "s";
        return sec + "s";
    }

    private static String escape(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 8);
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if ("\\*_~`|>[]()".indexOf(ch) >= 0) sb.append('\\');
            sb.append(ch);
        }
        return sb.toString();
    }

    private void status(Embed e, int online) {
        e.footerText = fmt(text("footer"), "", "", "", online);
        e.footerIcon = icon();
        sender.send(c().getString("webhooks.status", ""), Embed.payload(server(), icon(), null, List.of(e)));
    }

    /** Small plain line in the chat channel (joined / left / death / advancement). */
    private void chatLine(String line) {
        if (!c().getBoolean("chat.enabled", true) || !c().getBoolean("chat.system-lines", true)) return;
        sender.send(c().getString("webhooks.chat", ""), Embed.payload(server(), icon(), line, null));
    }

    // ------------------------------------------------------------------ join / leave

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        joined.put(p.getUniqueId(), System.currentTimeMillis());
        int online = Bukkit.getOnlinePlayers().size();
        boolean first = !p.hasPlayedBefore();

        if (first && c().getBoolean("status.first-join", true)) {
            Embed em = new Embed();
            em.title = text("first-join-title");
            em.description = fmt(text("first-join"), p.getName(), "", "", online);
            em.thumbnail = head(p);
            em.color = col("first-join", 0xFEE75C);
            status(em, online);
        } else if (c().getBoolean("status.join", true)) {
            Embed em = new Embed();
            em.authorName = fmt(text("join"), p.getName(), "", "", online);
            em.authorIcon = head(p);
            em.color = col("join", 0x57F287);
            status(em, online);
        }
        chatLine(fmt(text("chat-join"), p.getName(), "", "", online));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        int online = Math.max(0, Bukkit.getOnlinePlayers().size() - 1);
        Long start = joined.remove(p.getUniqueId());
        String time = start == null ? "" : duration(System.currentTimeMillis() - start);

        if (c().getBoolean("status.leave", true)) {
            Embed em = new Embed();
            em.authorName = fmt(text("leave"), p.getName(), "", "", online);
            em.authorIcon = head(p);
            if (!time.isEmpty()) em.description = fmt(text("leave-session"), p.getName(), "", time, online);
            em.color = col("leave", 0xED4245);
            status(em, online);
        }
        chatLine(fmt(text("chat-leave"), p.getName(), "", "", online));
    }

    // ------------------------------------------------------------------ deaths / advancements

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        String msg = plain(e.deathMessage());
        if (msg.isBlank()) return;
        Player p = e.getEntity();
        int online = Bukkit.getOnlinePlayers().size();
        if (c().getBoolean("status.deaths", true)) {
            Embed em = new Embed();
            em.authorName = fmt(text("death"), p.getName(), msg, "", online);
            em.authorIcon = head(p);
            em.color = col("death", 0x2B2D31);
            status(em, online);
        }
        chatLine(fmt(text("chat-death"), p.getName(), escape(msg), "", online));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onAdvancement(PlayerAdvancementDoneEvent e) {
        String msg = plain(e.message());
        if (msg.isBlank()) return; // hidden advancements / recipes
        Player p = e.getPlayer();
        int online = Bukkit.getOnlinePlayers().size();
        if (c().getBoolean("status.advancements", true)) {
            Embed em = new Embed();
            em.authorName = fmt(text("advancement"), p.getName(), msg, "", online);
            em.authorIcon = head(p);
            em.color = col("advancement", 0xA855F7);
            status(em, online);
        }
        chatLine(fmt(text("chat-advancement"), p.getName(), escape(msg), "", online));
    }

    // ------------------------------------------------------------------ live chat

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        if (!c().getBoolean("chat.enabled", true)) return;
        String url = c().getString("webhooks.chat", "");
        if (!DiscordSender.valid(url)) return;

        Player p = e.getPlayer();
        String msg = plain(e.message());
        if (msg.isBlank()) return;
        if (c().getBoolean("chat.escape-markdown", true)) msg = escape(msg);

        String tag = null;
        int rankColor = -1;
        for (Map<?, ?> m : c().getMapList("chat.ranks")) {
            Object perm = m.get("permission");
            if (perm != null && p.hasPermission(String.valueOf(perm))) {
                tag = String.valueOf(m.get("tag"));
                rankColor = hex(m.get("color"), 0xFFAA00);
                break;
            }
        }
        String display = (tag == null ? "" : "[" + tag + "] ") + p.getName();

        if ("plain".equalsIgnoreCase(c().getString("chat.style", "embed"))) {
            sender.send(url, Embed.payload(display, head(p), msg, null));
            return;
        }

        String worldName = text("world-overworld");
        int worldColor = col("overworld", 0x2ECC71);
        World.Environment env = p.getWorld().getEnvironment();
        if (env == World.Environment.NETHER) {
            worldName = text("world-nether");
            worldColor = col("nether", 0xE74C3C);
        } else if (env == World.Environment.THE_END) {
            worldName = text("world-end");
            worldColor = col("end", 0x9B59B6);
        }

        Embed em = new Embed();
        em.authorName = display;
        em.authorIcon = head(p);
        em.description = msg;
        em.color = rankColor >= 0 ? rankColor : worldColor;
        em.timestamp = false;
        if (c().getBoolean("chat.show-world", true)) em.footerText = worldName;
        sender.send(url, Embed.payload(server(), icon(), null, List.of(em)));
    }

    // ------------------------------------------------------------------ server start / stop (called by main class)

    void serverState(boolean online) {
        if (!c().getBoolean("status.server-start-stop", true)) return;
        int count = online ? Bukkit.getOnlinePlayers().size() : 0;
        Embed em = new Embed();
        em.title = text(online ? "server-online-title" : "server-offline-title");
        em.description = fmt(text(online ? "server-online" : "server-offline"), "", "", "", count);
        em.color = col(online ? "online" : "offline", online ? 0x57F287 : 0xED4245);
        status(em, count);
    }
}
